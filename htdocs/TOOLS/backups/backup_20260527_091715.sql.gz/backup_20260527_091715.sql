DROP TABLE IF EXISTS `asistencias`;
CREATE TABLE `asistencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL DEFAULT curtime(),
  `turno_id` tinyint(4) NOT NULL,
  `materia_id` int(11) DEFAULT NULL,
  `aula_id` int(11) DEFAULT NULL,
  `metodo_id` tinyint(4) NOT NULL DEFAULT 1,
  `foto_asistencia` varchar(255) DEFAULT NULL,
  `observacion` text DEFAULT NULL,
  `ubicacion_gps` point DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`,`fecha`,`turno_id`),
  UNIQUE KEY `unique_asistencia` (`usuario_id`,`fecha`,`turno_id`),
  KEY `turno_id` (`turno_id`),
  KEY `materia_id` (`materia_id`),
  KEY `aula_id` (`aula_id`),
  KEY `metodo_id` (`metodo_id`),
  CONSTRAINT `asistencias_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asistencias_ibfk_2` FOREIGN KEY (`turno_id`) REFERENCES `lk_turnos` (`id`),
  CONSTRAINT `asistencias_ibfk_3` FOREIGN KEY (`materia_id`) REFERENCES `lk_materias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `asistencias_ibfk_4` FOREIGN KEY (`aula_id`) REFERENCES `lk_aulas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `asistencias_ibfk_5` FOREIGN KEY (`metodo_id`) REFERENCES `lk_metodos_asistencia` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `asistencias` VALUES("13","1","2026-05-25","07:27:44","1","1","","3","uploads_asistencia/asis_1_1779719264.png","Materia ID 1","");
INSERT INTO `asistencias` VALUES("62","66","2026-05-10","08:00:00","1","1","1","1","foto1.jpg","Asistencia correcta","");
INSERT INTO `asistencias` VALUES("63","67","2026-05-10","08:15:00","1","2","2","2","","Registro manual","");
INSERT INTO `asistencias` VALUES("64","68","2026-05-10","08:30:00","1","3","3","1","foto3.jpg","Ingreso puntual","");
INSERT INTO `asistencias` VALUES("65","69","2026-05-11","14:00:00","2","4","1","3","","Registro admin","");
INSERT INTO `asistencias` VALUES("66","70","2026-05-11","14:20:00","2","1","2","1","foto5.jpg","Asistencia","");

DROP TABLE IF EXISTS `lk_aulas`;
CREATE TABLE `lk_aulas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lk_aulas` VALUES("1","Aula 101");
INSERT INTO `lk_aulas` VALUES("2","Aula 102");
INSERT INTO `lk_aulas` VALUES("3","Laboratorio 1");

DROP TABLE IF EXISTS `lk_materias`;
CREATE TABLE `lk_materias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lk_materias` VALUES("4","CAI-500a");
INSERT INTO `lk_materias` VALUES("1","SII-500a");
INSERT INTO `lk_materias` VALUES("2","TEL-500a");
INSERT INTO `lk_materias` VALUES("3","TMG-500a");

DROP TABLE IF EXISTS `lk_metodos_asistencia`;
CREATE TABLE `lk_metodos_asistencia` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lk_metodos_asistencia` VALUES("3","admin");
INSERT INTO `lk_metodos_asistencia` VALUES("1","facial");
INSERT INTO `lk_metodos_asistencia` VALUES("2","manual");

DROP TABLE IF EXISTS `lk_turnos`;
CREATE TABLE `lk_turnos` (
  `id` tinyint(4) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `lk_turnos` VALUES("1","manana","08:00:00","13:10:00");
INSERT INTO `lk_turnos` VALUES("2","tarde","14:00:00","18:10:00");
INSERT INTO `lk_turnos` VALUES("3","noche","18:00:00","22:40:00");

DROP TABLE IF EXISTS `solicitudes_registro`;
CREATE TABLE `solicitudes_registro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_ci` varchar(15) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `paterno` varchar(100) NOT NULL,
  `materno` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contrasena` varchar(255) DEFAULT NULL,
  `fecha_solicitud` timestamp NOT NULL DEFAULT current_timestamp(),
  `estado` enum('pendiente','rechazada','aceptada') DEFAULT 'pendiente',
  `codigo_verificacion` varchar(6) DEFAULT NULL,
  `verificado` tinyint(4) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nro_ci` varchar(15) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `paterno` varchar(100) NOT NULL,
  `materno` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contrasena` varchar(255) NOT NULL,
  `foto` longtext DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `must_change` tinyint(1) NOT NULL DEFAULT 1,
  `rol` enum('estudiante','docente','superusuario') NOT NULL DEFAULT 'estudiante',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nro_ci` (`nro_ci`),
  KEY `idx_ci` (`nro_ci`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usuarios` VALUES("1","1","Adrian ","s","gfgf","the9999ban@gmail.com","$2y$10$HjqIIt2SM4D9gzP079tUvuLpai.GhLGBnH/V9./V9Lxwy3xVMY8V.","default.png","","0","estudiante");
INSERT INTO `usuarios` VALUES("2","2","docente","Mamani","Quispe","the9999ban@gmail.com","$2y$10$nc6znLUUiKNpyYIn1YA1xuIyw627AAQ2Tk/U/UPvjiypL0kLNUr4G","default.png","","0","docente");
INSERT INTO `usuarios` VALUES("3","3","superusuario","fd","fd","the9999ban@gmail.com","$2y$10$7iYF00dEy71Lk.IUY1DNW.O4Zvi1/RHPXFRnw0kQWJ9UigljIEhpy","default.png","","0","superusuario");
INSERT INTO `usuarios` VALUES("66","1000001","Juan","Perez","Lopez","juan1@gmail.com","123456","","70000001","0","estudiante");
INSERT INTO `usuarios` VALUES("67","1000002","Maria","Condori","Quispe","maria2@gmail.com","123456","","70000002","0","estudiante");
INSERT INTO `usuarios` VALUES("68","1000003","Carlos","Mamani","Flores","carlos3@gmail.com","123456","","70000003","0","estudiante");
INSERT INTO `usuarios` VALUES("69","1000004","Ana","Rojas","Mendez","ana4@gmail.com","123456","","70000004","0","estudiante");
INSERT INTO `usuarios` VALUES("70","1000005","Luis","Gomez","Ramos","luis5@gmail.com","123456","","70000005","0","estudiante");
INSERT INTO `usuarios` VALUES("71","1000006","Sofia","Luna","Diaz","sofia6@gmail.com","123456","","70000006","0","estudiante");
INSERT INTO `usuarios` VALUES("72","1000007","Pedro","Vargas","Quisbert","pedro7@gmail.com","123456","","70000007","0","estudiante");
INSERT INTO `usuarios` VALUES("73","1000008","Lucia","Choque","Mora","lucia8@gmail.com","123456","","70000008","0","estudiante");
INSERT INTO `usuarios` VALUES("74","1000009","Diego","Torrez","Paredes","diego9@gmail.com","123456","","70000009","0","estudiante");
INSERT INTO `usuarios` VALUES("75","1000010","Fernanda","Arias","Loza","fernanda10@gmail.com","123456","","70000010","0","estudiante");
INSERT INTO `usuarios` VALUES("76","1000011","Miguel","Castro","Rojas","miguel11@gmail.com","123456","","70000011","0","estudiante");
INSERT INTO `usuarios` VALUES("77","1000012","Gabriela","Salazar","Flores","gabriela12@gmail.com","123456","","70000012","0","estudiante");
INSERT INTO `usuarios` VALUES("78","1000013","Jorge","Nina","Mamani","jorge13@gmail.com","123456","","70000013","0","estudiante");
INSERT INTO `usuarios` VALUES("79","1000014","Valeria","Herrera","Luna","valeria14@gmail.com","123456","","70000014","0","estudiante");
INSERT INTO `usuarios` VALUES("80","1000015","Andres","Mendoza","Pinto","andres15@gmail.com","123456","","70000015","0","estudiante");
INSERT INTO `usuarios` VALUES("81","1000016","Camila","Rivera","Soto","camila16@gmail.com","123456","","70000016","0","estudiante");

